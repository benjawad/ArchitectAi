
from models.user import User
from models.product import Product
from services.payment import PaymentProcessor
from cart import ShoppingCart

def main():
    # Create user
    user = User(1, "John Doe", "john@example.com")
    
    # Create products
    laptop = Product(1, "Laptop", 999.99, 5)
    mouse = Product(2, "Mouse", 29.99, 50)
    
    # Shopping
    cart = ShoppingCart(user.user_id)
    cart.add_item(laptop, 1)
    cart.add_item(mouse, 2)
    
    print(f"Total: ${cart.get_total()}")

if __name__ == "__main__":
    main()
