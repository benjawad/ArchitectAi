
# GOOD: Builder pattern for complex order creation

from models.order import Order

class OrderBuilder:
    def __init__(self, user_id):
        self.order = Order(order_id=None, user_id=user_id)
    
    def add_product(self, product, quantity):
        self.order.add_item(product, quantity)
        return self
    
    def set_shipping_address(self, address):
        self.order.shipping_address = address
        return self
    
    def set_billing_address(self, address):
        self.order.billing_address = address
        return self
    
    def build(self):
        return self.order
