
from datetime import datetime

class Order:
    def __init__(self, order_id, user_id):
        self.order_id = order_id
        self.user_id = user_id
        self.items = []
        self.status = "pending"
        self.created_at = datetime.now()
        self.total = 0
    
    def add_item(self, product, quantity):
        self.items.append({
            "product": product,
            "quantity": quantity,
            "price": product.price
        })
        self.total += product.price * quantity
    
    def process(self):
        self.status = "processing"
    
    def complete(self):
        self.status = "completed"
