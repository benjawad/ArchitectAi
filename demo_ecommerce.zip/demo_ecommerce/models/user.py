
class User:
    def __init__(self, user_id, name, email):
        self.user_id = user_id
        self.name = name
        self.email = email
        self.orders = []
    
    def add_order(self, order):
        self.orders.append(order)
    
    def get_total_spent(self):
        return sum(order.total for order in self.orders)
