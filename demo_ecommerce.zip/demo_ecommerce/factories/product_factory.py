
# GOOD: Factory pattern for product creation

from models.product import Product

class ProductFactory:
    @staticmethod
    def create_electronic(name, price):
        return Product(
            product_id=f"ELEC-{name}",
            name=name,
            price=price,
            stock=10
        )
    
    @staticmethod
    def create_clothing(name, price):
        return Product(
            product_id=f"CLOTH-{name}",
            name=name,
            price=price,
            stock=50
        )
    
    @staticmethod
    def create_book(name, price):
        return Product(
            product_id=f"BOOK-{name}",
            name=name,
            price=price,
            stock=100
        )
