
# BAD: Using if/else for different payment methods
# Should use Strategy pattern!

class PaymentProcessor:
    def process_payment(self, order, payment_method):
        if payment_method == "credit_card":
            return self._process_credit_card(order)
        elif payment_method == "paypal":
            return self._process_paypal(order)
        elif payment_method == "bitcoin":
            return self._process_bitcoin(order)
        elif payment_method == "bank_transfer":
            return self._process_bank_transfer(order)
        else:
            raise ValueError("Unknown payment method")
    
    def _process_credit_card(self, order):
        # Credit card processing logic
        print(f"Processing ${order.total} via Credit Card")
        return True
    
    def _process_paypal(self, order):
        # PayPal processing logic
        print(f"Processing ${order.total} via PayPal")
        return True
    
    def _process_bitcoin(self, order):
        # Bitcoin processing logic
        print(f"Processing ${order.total} via Bitcoin")
        return True
    
    def _process_bank_transfer(self, order):
        # Bank transfer processing logic
        print(f"Processing ${order.total} via Bank Transfer")
        return True
