
# BAD: Tight coupling for notifications
# Should use Observer pattern!

class NotificationService:
    def __init__(self):
        self.email_service = EmailService()
        self.sms_service = SMSService()
        self.push_service = PushService()
    
    def notify_order_created(self, order):
        self.email_service.send_email(order.user_id, "Order created")
        self.sms_service.send_sms(order.user_id, "Order created")
        self.push_service.send_push(order.user_id, "Order created")
    
    def notify_order_shipped(self, order):
        self.email_service.send_email(order.user_id, "Order shipped")
        self.sms_service.send_sms(order.user_id, "Order shipped")

class EmailService:
    def send_email(self, user_id, message):
        print(f"Email to {user_id}: {message}")

class SMSService:
    def send_sms(self, user_id, message):
        print(f"SMS to {user_id}: {message}")

class PushService:
    def send_push(self, user_id, message):
        print(f"Push to {user_id}: {message}")
