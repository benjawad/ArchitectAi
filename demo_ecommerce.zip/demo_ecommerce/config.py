
DATABASE_URL = "postgresql://localhost/ecommerce"
REDIS_URL = "redis://localhost:6379"
SECRET_KEY = "your-secret-key"
DEBUG = True
