
class ShoppingCart:
    def __init__(self, user_id):
        self.user_id = user_id
        self.items = []
    
    def add_item(self, product, quantity):
        self.items.append({"product": product, "quantity": quantity})
    
    def remove_item(self, product_id):
        self.items = [item for item in self.items if item["product"].product_id != product_id]
    
    def get_total(self):
        return sum(item["product"].price * item["quantity"] for item in self.items)
    
    def clear(self):
        self.items = []
