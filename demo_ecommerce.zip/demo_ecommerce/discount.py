
class DiscountCalculator:
    def apply_percentage_discount(self, total, percentage):
        return total * (1 - percentage / 100)
    
    def apply_fixed_discount(self, total, amount):
        return max(0, total - amount)
    
    def apply_bulk_discount(self, quantity, price):
        if quantity >= 10:
            return price * 0.9
        return price
