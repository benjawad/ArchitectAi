
# BAD: Multiple if/else for auth methods
# Should use Strategy pattern!

class AuthService:
    def authenticate(self, credentials, method):
        if method == "jwt":
            return self._verify_jwt(credentials)
        elif method == "oauth":
            return self._verify_oauth(credentials)
        elif method == "api_key":
            return self._verify_api_key(credentials)
        else:
            return False
    
    def _verify_jwt(self, token):
        print(f"Verifying JWT: {token}")
        return True
    
    def _verify_oauth(self, token):
        print(f"Verifying OAuth: {token}")
        return True
    
    def _verify_api_key(self, key):
        print(f"Verifying API Key: {key}")
        return True
