
from fastapi import FastAPI, HTTPException
from models import User, Product, Order
from database import Database

app = FastAPI()
db = Database()

@app.get("/")
def read_root():
    return {"message": "FastAPI E-commerce API"}

@app.get("/users/{user_id}")
def get_user(user_id: int):
    user = db.get_user(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user

@app.post("/users")
def create_user(user: User):
    return db.create_user(user)

@app.get("/products")
def list_products():
    return db.get_all_products()

@app.post("/orders")
def create_order(order: Order):
    return db.create_order(order)
