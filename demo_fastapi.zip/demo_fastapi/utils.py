
from datetime import datetime

def get_timestamp():
    return datetime.now().isoformat()

def validate_email(email):
    return "@" in email

def hash_password(password):
    # Simplified for demo
    return f"hashed_{password}"
