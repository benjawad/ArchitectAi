
from abc import ABC, abstractmethod

class Repository(ABC):
    @abstractmethod
    def find_by_id(self, id):
        pass
    
    @abstractmethod
    def save(self, entity):
        pass
    
    @abstractmethod
    def delete(self, id):
        pass

class UserRepository(Repository):
    def __init__(self):
        self.storage = {}
    
    def find_by_id(self, id):
        return self.storage.get(id)
    
    def save(self, entity):
        self.storage[entity.user_id] = entity
    
    def delete(self, id):
        if id in self.storage:
            del self.storage[id]
