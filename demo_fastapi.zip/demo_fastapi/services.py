
class UserService:
    def __init__(self, repository):
        self.repository = repository
    
    def register_user(self, name, email):
        from models import User
        user = User(name=name, email=email)
        self.repository.save(user)
        return user
    
    def get_user_profile(self, user_id):
        return self.repository.find_by_id(user_id)

class OrderService:
    def __init__(self):
        self.orders = []
    
    def create_order(self, user_id, items):
        from models import Order
        order = Order(user_id=user_id, items=items)
        self.orders.append(order)
        return order
