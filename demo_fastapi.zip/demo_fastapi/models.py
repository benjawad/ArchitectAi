
from pydantic import BaseModel
from typing import List, Optional

class User(BaseModel):
    user_id: Optional[int] = None
    name: str
    email: str

class Product(BaseModel):
    product_id: Optional[int] = None
    name: str
    price: float
    stock: int

class OrderItem(BaseModel):
    product_id: int
    quantity: int

class Order(BaseModel):
    order_id: Optional[int] = None
    user_id: int
    items: List[OrderItem]
    total: float = 0.0
