
# BAD: Should be Singleton!

class Database:
    def __init__(self):
        self.users = {}
        self.products = {}
        self.orders = {}
        self.next_user_id = 1
        self.next_product_id = 1
        self.next_order_id = 1
    
    def get_user(self, user_id):
        return self.users.get(user_id)
    
    def create_user(self, user):
        user.user_id = self.next_user_id
        self.users[user.user_id] = user
        self.next_user_id += 1
        return user
    
    def get_all_products(self):
        return list(self.products.values())
    
    def create_order(self, order):
        order.order_id = self.next_order_id
        self.orders[order.order_id] = order
        self.next_order_id += 1
        return order
